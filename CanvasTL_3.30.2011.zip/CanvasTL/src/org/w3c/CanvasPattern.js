vjo.ctype('org.w3c.CanvasPattern') //< public
/**
 * interface CanvasPattern {
  // opaque object
};

 */
.protos({
	
})
.options({
	metatype:true
})
.endType();