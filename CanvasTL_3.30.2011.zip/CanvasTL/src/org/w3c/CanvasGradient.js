vjo.ctype('org.w3c.CanvasGradient') //< public
/**
 * interface CanvasGradient {
  // opaque object 
  void addColorStop(in float offset, in DOMString color);
};
 */
.protos({
	addColorStop:vjo.NEEDS_IMPL //< public void addColorStop(float offset, String color);
})
.options({
	metatype:true
})
.endType();