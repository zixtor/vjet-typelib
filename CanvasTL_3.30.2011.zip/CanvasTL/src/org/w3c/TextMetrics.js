vjo.ctype('org.w3c.TextMetrics') //< public
/**
 * interface TextMetrics {
  readonly attribute float width;
};
 */
.protos({
	width:undefined // < public float
})
.options({
	metatype:true
})
.endType();