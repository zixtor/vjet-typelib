var factoryFunctionMappings = {
	'HTMLCanvasElement:getContext' : {
		'2D' :   'org.w3c.CanvasRenderingContext2D',
		'2d' :   'org.w3c.CanvasRenderingContext2D'
    }
}