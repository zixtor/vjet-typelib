vjo.ctype('org.json.JSON') //< public
.globals({
	JSON : undefined //<<type::JSON
})
.props({
	//> public String parse(String text, Function? reviver)
	parse:vjo.NEEDS_IMPL,
	//> public String stringify(Object value, Function? replacer, String? space)
	stringify:vjo.NEEDS_IMPL
})
.options({
	metatype:true
})
.endType();