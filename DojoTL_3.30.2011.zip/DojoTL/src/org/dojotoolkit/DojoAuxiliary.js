vjo.otype('org.dojotoolkit.DojoAuxiliary') //< public
.defs({
	__AnimArgs : {
		easing : null, //<public (boolean easing(int index))?
		duration : 0, //<public Number
		node : null, //<public Node?
		onEnd : null, //<public (void onEnd(Node node))?
		properties : null //<public Object?
	},

	__XhrArgs : {
		error : vjo.NEEDS_IMPL, //<public void error()				
		handle : vjo.NEEDS_IMPL, //<public void handle()		
		load : vjo.NEEDS_IMPL, //<public void load()		
		content : null, //<public Object
		form : null, //<public Node
		handleAs : null, //<public String
		headers : null, //<public Object
		preventCache : false, //<public boolean
		sync : false, //<public boolean
		timeout : 0, //<public int
		url : null //<public String
	},
	
	__FadeArgs : {
		easing: null, //<<public boolean easing(int)
		duration: 0, //<public Number
		node: null //<public Node
	},
	
	__Coords : {
		l : 0, //<public int
		t : 0, //<public int
		w : 0, //<public int
		h : 0, //<public int
		x : 0, //<public int
		y : 0 //<public int		
	},
	
	__Margin : {
		l : 0, //<public int
		t : 0, //<public int
		w : 0, //<public int
		h : 0 //<public int		
	},
	
	__CSS2Properties : {
		width : 0, //<public int
		height : 0 //<public int
		//more ...		
	}
})
.endType();
